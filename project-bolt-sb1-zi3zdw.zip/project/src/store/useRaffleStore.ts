import { create } from 'zustand';

interface RaffleState {
  dailyRaffleProgress: number;
  weeklyRaffleProgress: number;
  dailyEntries: number;
  weeklyEntries: number;
  hasEnteredDailyRaffle: boolean;
  hasEnteredWeeklyRaffle: boolean;
  setDailyRaffleProgress: (progress: number) => void;
  setWeeklyRaffleProgress: (progress: number) => void;
  setDailyEntries: (entries: number) => void;
  setWeeklyEntries: (entries: number) => void;
  setHasEnteredDailyRaffle: (entered: boolean) => void;
  setHasEnteredWeeklyRaffle: (entered: boolean) => void;
}

export const useRaffleStore = create<RaffleState>((set) => ({
  dailyRaffleProgress: 0,
  weeklyRaffleProgress: 0,
  dailyEntries: 0,
  weeklyEntries: 0,
  hasEnteredDailyRaffle: false,
  hasEnteredWeeklyRaffle: false,
  setDailyRaffleProgress: (progress) => set({ dailyRaffleProgress: progress }),
  setWeeklyRaffleProgress: (progress) => set({ weeklyRaffleProgress: progress }),
  setDailyEntries: (entries) => set({ dailyEntries: entries }),
  setWeeklyEntries: (entries) => set({ weeklyEntries: entries }),
  setHasEnteredDailyRaffle: (entered) => set({ hasEnteredDailyRaffle: entered }),
  setHasEnteredWeeklyRaffle: (entered) => set({ hasEnteredWeeklyRaffle: entered }),
}));