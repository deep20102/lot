import { create } from 'zustand';

interface LotteryState {
  dailyLotteryProgress: number;
  weeklyLotteryProgress: number;
  hasEnteredDailyLottery: boolean;
  hasEnteredWeeklyLottery: boolean;
  setDailyLotteryProgress: (progress: number) => void;
  setWeeklyLotteryProgress: (progress: number) => void;
  setHasEnteredDailyLottery: (entered: boolean) => void;
  setHasEnteredWeeklyLottery: (entered: boolean) => void;
}

export const useLotteryStore = create<LotteryState>((set) => ({
  dailyLotteryProgress: 0,
  weeklyLotteryProgress: 0,
  hasEnteredDailyLottery: false,
  hasEnteredWeeklyLottery: false,
  setDailyLotteryProgress: (progress) => set({ dailyLotteryProgress: progress }),
  setWeeklyLotteryProgress: (progress) => set({ weeklyLotteryProgress: progress }),
  setHasEnteredDailyLottery: (entered) => set({ hasEnteredDailyLottery: entered }),
  setHasEnteredWeeklyLottery: (entered) => set({ hasEnteredWeeklyLottery: entered }),
}));