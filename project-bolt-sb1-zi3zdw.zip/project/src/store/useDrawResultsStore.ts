import { create } from 'zustand';

interface DrawResult {
  id: string;
  type: 'daily-lottery' | 'weekly-lottery' | 'daily-raffle' | 'weekly-raffle';
  drawTime: Date;
  winningNumbers?: number[];
  winningTicket?: number;
  prizeAmount: number;
  winner: {
    username: string;
    email: string;
    ethAddress?: string;
    claimed: boolean;
    notified?: boolean;
    transactionHash?: string;
    claimDeadline?: Date;
  };
}

interface DrawResultsState {
  results: DrawResult[];
  addResult: (result: DrawResult) => void;
  updateResult: (id: string, updates: Partial<DrawResult>) => void;
  getResultById: (id: string) => DrawResult | undefined;
  getPendingClaims: () => DrawResult[];
}

export const useDrawResultsStore = create<DrawResultsState>((set, get) => ({
  results: [],
  addResult: (result) => set((state) => ({ 
    results: [...state.results, result] 
  })),
  updateResult: (id, updates) => set((state) => ({
    results: state.results.map(result => 
      result.id === id ? { ...result, ...updates } : result
    )
  })),
  getResultById: (id) => get().results.find(result => result.id === id),
  getPendingClaims: () => get().results.filter(
    result => !result.winner.claimed && result.winner.claimDeadline && new Date() < result.winner.claimDeadline
  ),
}));

export type { DrawResult };