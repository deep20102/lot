import { History } from 'lucide-react';

export default function LotteryHistory() {
  // Mock data - replace with actual API data
  const history = [
    {
      id: 1,
      type: 'Daily Lottery',
      date: '2024-03-19',
      numbers: [7, 13, 24, 35, 46, 71],
      winningNumbers: [7, 13, 24, 35, 46, 72],
      prize: 0,
      matches: 5
    },
    {
      id: 2,
      type: 'Weekly Lottery',
      date: '2024-03-18',
      numbers: [3, 11, 22, 33, 44, 55],
      winningNumbers: [3, 11, 22, 33, 44, 55],
      prize: 500,
      matches: 6
    },
    {
      id: 3,
      type: 'Daily Raffle',
      date: '2024-03-19',
      entryNumber: 45,
      winningNumber: 87,
      prize: 0
    },
    {
      id: 4,
      type: 'Weekly Raffle',
      date: '2024-03-18',
      entryNumber: 123,
      winningNumber: 123,
      prize: 500
    }
  ];

  return (
    <div className="max-w-4xl mx-auto text-white">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
        <div className="flex items-center space-x-3 mb-8">
          <History className="w-8 h-8 text-yellow-400" />
          <h1 className="text-3xl font-bold">Lottery History</h1>
        </div>

        <div className="space-y-4">
          {history.map((entry) => (
            <div key={entry.id} className="bg-black/20 rounded-xl p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold mb-2 ${
                    entry.type.includes('Daily') ? 'bg-purple-600' : 'bg-yellow-600'
                  }`}>
                    {entry.type}
                  </span>
                  <div className="text-gray-400">{entry.date}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-400">Prize Won</div>
                  <div className="text-xl font-bold text-yellow-400">
                    ${entry.prize.toFixed(2)}
                  </div>
                </div>
              </div>

              {'numbers' in entry ? (
                <div className="space-y-4">
                  <div>
                    <div className="text-sm text-gray-400 mb-2">Your Numbers</div>
                    <div className="flex space-x-2">
                      {entry.numbers.map((num, index) => (
                        <div
                          key={index}
                          className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                            entry.winningNumbers.includes(num)
                              ? 'bg-green-500 text-white'
                              : 'bg-white/10'
                          }`}
                        >
                          {num}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-gray-400 mb-2">Winning Numbers</div>
                    <div className="flex space-x-2">
                      {entry.winningNumbers.map((num, index) => (
                        <div
                          key={index}
                          className="w-10 h-10 rounded-full bg-yellow-400 text-black flex items-center justify-center font-bold"
                        >
                          {num}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="text-center pt-4 border-t border-white/10">
                    <span className="text-lg">
                      Matched <span className="text-yellow-400 font-bold">{entry.matches}</span> numbers
                    </span>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <div className="text-sm text-gray-400 mb-2">Your Entry Number</div>
                    <div className="text-2xl font-bold">#{entry.entryNumber}</div>
                  </div>

                  <div>
                    <div className="text-sm text-gray-400 mb-2">Winning Number</div>
                    <div className="text-2xl font-bold text-yellow-400">#{entry.winningNumber}</div>
                  </div>

                  <div className="text-center pt-4 border-t border-white/10">
                    <span className="text-lg">
                      {entry.entryNumber === entry.winningNumber ? (
                        <span className="text-green-500">Winner!</span>
                      ) : (
                        <span className="text-gray-400">Better luck next time</span>
                      )}
                    </span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}