import { useState } from 'react';
import { Shuffle, RotateCcw, DollarSign } from 'lucide-react';
import { useTimer, getNextDailyEndTime } from '../hooks/useTimer';

export default function Entry() {
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
  const [dailyEndTime] = useState(getNextDailyEndTime());
  const { timeLeft, isExpired } = useTimer(dailyEndTime);
  const [isAnimating, setIsAnimating] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleNumberClick = (num: number) => {
    if (selectedNumbers.includes(num)) {
      setSelectedNumbers(selectedNumbers.filter(n => n !== num));
    } else if (selectedNumbers.length < 6) {
      setSelectedNumbers([...selectedNumbers, num]);
    }
  };

  const quickPick = () => {
    setIsAnimating(true);
    const numbers: number[] = [];
    let currentIndex = 0;

    const interval = setInterval(() => {
      if (currentIndex < 6) {
        let num;
        do {
          num = Math.floor(Math.random() * 75) + 1;
        } while (numbers.includes(num));
        numbers.push(num);
        setSelectedNumbers([...numbers]);
        currentIndex++;
      } else {
        clearInterval(interval);
        setIsAnimating(false);
      }
    }, 200);
  };

  const reset = () => {
    setSelectedNumbers([]);
  };

  const handleSubmit = () => {
    // API call would go here
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const formatTime = (value: number) => value.toString().padStart(2, '0');

  return (
    <div className="max-w-4xl mx-auto text-white">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-4">Daily Draw</h1>
          <div className="flex justify-center items-center space-x-2 text-yellow-400 text-2xl mb-6">
            <DollarSign className="w-8 h-8" />
            <span className="font-bold">50 Prize Pool</span>
          </div>
          
          <div className="mb-8">
            <img
              src="https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?auto=format&fit=crop&q=80&w=2000"
              alt="Daily Lottery"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>

          <div className="mb-8">
            <p className="text-center text-yellow-400 mb-4">Time Left To Play</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <div className="bg-black/30 backdrop-blur-sm p-3 rounded-xl text-center">
                <div className="text-2xl font-bold">{formatTime(timeLeft.hours)}</div>
                <div className="text-xs text-gray-400">Hours</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-3 rounded-xl text-center">
                <div className="text-2xl font-bold">{formatTime(timeLeft.minutes)}</div>
                <div className="text-xs text-gray-400">Minutes</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-3 rounded-xl text-center">
                <div className="text-2xl font-bold">{formatTime(timeLeft.seconds)}</div>
                <div className="text-xs text-gray-400">Seconds</div>
              </div>
            </div>
          </div>

          <p className="text-lg text-yellow-400 mb-6">Select 6 numbers from 1 to 75</p>
        </div>

        <div className="grid grid-cols-10 gap-2 mb-8">
          {Array.from({ length: 75 }, (_, i) => i + 1).map(num => (
            <button
              key={num}
              onClick={() => handleNumberClick(num)}
              disabled={isExpired || (selectedNumbers.length >= 6 && !selectedNumbers.includes(num))}
              className={`aspect-square rounded-lg font-bold text-sm transition-all duration-200
                ${selectedNumbers.includes(num)
                  ? 'bg-yellow-400 text-black transform scale-110'
                  : isExpired
                  ? 'bg-gray-600 cursor-not-allowed'
                  : 'bg-white/5 hover:bg-white/20'
                }
                ${isAnimating ? 'animate-pulse' : ''}`}
            >
              {num}
            </button>
          ))}
        </div>

        <div className="flex justify-center space-x-4 mb-8">
          <button
            onClick={quickPick}
            disabled={isExpired || isAnimating}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg
              ${isExpired || isAnimating
                ? 'bg-gray-600 cursor-not-allowed'
                : 'bg-purple-600 hover:bg-purple-700'
              }`}
          >
            <Shuffle className="w-4 h-4" />
            <span>Quick Pick</span>
          </button>
          <button
            onClick={reset}
            className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset</span>
          </button>
        </div>

        <div className="mb-8">
          <h2 className="text-center text-lg mb-4">Your Chosen Numbers</h2>
          <div className="flex justify-center space-x-3">
            {Array.from({ length: 6 }, (_, i) => (
              <div
                key={i}
                className={`w-12 h-12 rounded-full flex items-center justify-center font-bold transition-all duration-300
                  ${selectedNumbers[i] ? 'bg-yellow-400 text-black' : 'bg-white/10'}`}
              >
                {selectedNumbers[i] || ''}
              </div>
            ))}
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={handleSubmit}
            disabled={selectedNumbers.length !== 6 || isExpired}
            className={`px-8 py-3 rounded-full font-bold
              ${isExpired
                ? 'bg-gray-600 cursor-not-allowed'
                : selectedNumbers.length === 6
                ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-black hover:from-yellow-500 hover:to-yellow-600'
                : 'bg-gray-600 cursor-not-allowed'
              }`}
          >
            {isExpired ? 'Entry Closed' : 'Submit Entry'}
          </button>
        </div>

        {/* Success Message */}
        {showSuccess && (
          <div className="fixed inset-0 flex items-center justify-center z-50">
            <div className="bg-green-500 text-white px-6 py-3 rounded-lg shadow-xl">
              Entry submitted successfully!
            </div>
          </div>
        )}
      </div>
    </div>
  );
}