import { useState } from 'react';
import { DollarSign, Circle } from 'lucide-react';
import { useTimer, getWeeklyEndTime } from '../hooks/useTimer';
import { useRaffleStore } from '../store/useRaffleStore';

export default function WeeklyRaffle() {
  const [weeklyEndTime] = useState(getWeeklyEndTime());
  const { timeLeft, isExpired } = useTimer(weeklyEndTime);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const { 
    weeklyEntries, 
    hasEnteredWeeklyRaffle,
    dailyRaffleProgress,
    setWeeklyEntries,
    setHasEnteredWeeklyRaffle
  } = useRaffleStore();
  
  const nextEntryNumber = weeklyEntries + 1;
  const [userEntryNumber, setUserEntryNumber] = useState<number | null>(null);

  const formatTime = (value: number) => value.toString().padStart(2, '0');

  const handleSubmitEntry = () => {
    if (hasEnteredWeeklyRaffle || dailyRaffleProgress < 4) return;
    setShowConfirmModal(true);
  };

  const confirmEntry = () => {
    setWeeklyEntries(weeklyEntries + 1);
    setHasEnteredWeeklyRaffle(true);
    setUserEntryNumber(nextEntryNumber);
    setShowConfirmModal(false);
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto text-white">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-4">Weekly Raffle</h1>
          <div className="flex justify-center items-center space-x-2 text-yellow-400 text-2xl mb-6">
            <DollarSign className="w-8 h-8" />
            <span className="font-bold">500 Prize Pool</span>
          </div>

          <div className="mb-8">
            <img
              src="https://images.unsplash.com/photo-1560472355-536de3962603?auto=format&fit=crop&q=80&w=2000"
              alt="Weekly Raffle"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>

          <div className="relative w-16 h-16 mx-auto mb-6">
            <Circle 
              className={`w-full h-full ${
                dailyRaffleProgress >= 4 ? 'text-green-500' : 'text-red-500'
              }`}
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-lg font-bold">{dailyRaffleProgress}/4</span>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-2">Total Entrants</h2>
            <div className="text-4xl font-bold text-yellow-400 mb-6">{weeklyEntries}</div>
            
            {userEntryNumber && (
              <div className="mb-6">
                <div className="text-lg text-gray-400 mb-2">Your Ticket</div>
                <div className="text-3xl font-bold text-yellow-400">#{userEntryNumber}</div>
              </div>
            )}

            <p className="text-center text-yellow-400 mb-4">Time Left To Play</p>
            <div className="grid grid-cols-4 gap-4 max-w-xl mx-auto">
              <div className="bg-black/30 backdrop-blur-sm p-3 rounded-xl text-center">
                <div className="text-2xl font-bold">{timeLeft.days}</div>
                <div className="text-xs text-gray-400">Days</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-3 rounded-xl text-center">
                <div className="text-2xl font-bold">{formatTime(timeLeft.hours)}</div>
                <div className="text-xs text-gray-400">Hours</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-3 rounded-xl text-center">
                <div className="text-2xl font-bold">{formatTime(timeLeft.minutes)}</div>
                <div className="text-xs text-gray-400">Minutes</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-3 rounded-xl text-center">
                <div className="text-2xl font-bold">{formatTime(timeLeft.seconds)}</div>
                <div className="text-xs text-gray-400">Seconds</div>
              </div>
            </div>
          </div>

          <button
            onClick={handleSubmitEntry}
            disabled={isExpired || hasEnteredWeeklyRaffle || dailyRaffleProgress < 4}
            className={`px-8 py-3 rounded-full font-bold
              ${isExpired || dailyRaffleProgress < 4
                ? 'bg-gray-600 cursor-not-allowed'
                : hasEnteredWeeklyRaffle
                ? 'bg-gray-600 cursor-not-allowed'
                : 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-black hover:from-yellow-500 hover:to-yellow-600'
              }`}
          >
            {isExpired 
              ? 'Entry Closed' 
              : dailyRaffleProgress < 4
              ? 'Complete Daily Entries First'
              : hasEnteredWeeklyRaffle 
              ? 'Already Entered' 
              : 'Submit Entry'}
          </button>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 rounded-2xl p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold mb-4">Confirm Entry</h2>
            <p className="mb-6">Your entry number will be:</p>
            <div className="text-4xl font-bold text-yellow-400 text-center mb-8">
              #{nextEntryNumber}
            </div>
            <div className="flex justify-end space-x-4">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-6 py-2 rounded-lg bg-gray-700 hover:bg-gray-600"
              >
                Cancel
              </button>
              <button
                onClick={confirmEntry}
                className="px-6 py-2 rounded-lg bg-yellow-400 text-black hover:bg-yellow-500"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Message */}
      {showSuccessMessage && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          <div className="bg-green-500 text-white px-6 py-3 rounded-lg shadow-xl">
            Entry submitted successfully!
          </div>
        </div>
      )}
    </div>
  );
}