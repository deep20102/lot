import { useState, useEffect } from 'react';
import { Timer, DollarSign, Circle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useTimer, getNextDailyEndTime, getWeeklyEndTime, isLotteryVisible, isWeeklyLotteryVisible } from '../hooks/useTimer';
import { useRaffleStore } from '../store/useRaffleStore';

export default function Home() {
  const [dailyEndTime] = useState(getNextDailyEndTime());
  const [weeklyEndTime] = useState(getWeeklyEndTime());
  const [showDaily, setShowDaily] = useState(true);
  const [showWeekly, setShowWeekly] = useState(true);
  const { dailyRaffleProgress } = useRaffleStore();
  
  const { timeLeft: dailyTimeLeft, isExpired: dailyExpired } = useTimer(dailyEndTime);
  const { timeLeft: weeklyTimeLeft, isExpired: weeklyExpired } = useTimer(weeklyEndTime);

  useEffect(() => {
    const checkVisibility = () => {
      setShowDaily(isLotteryVisible());
      setShowWeekly(isWeeklyLotteryVisible());
    };

    const interval = setInterval(checkVisibility, 1000);
    checkVisibility();

    return () => clearInterval(interval);
  }, []);

  const formatTime = (value: number) => value.toString().padStart(2, '0');

  return (
    <div className="max-w-4xl mx-auto text-white space-y-8">
      {/* Daily Lottery */}
      {showDaily && (
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-4">Daily Lottery</h1>
            <div className="flex justify-center items-center space-x-2 text-yellow-400 text-2xl mb-6">
              <DollarSign className="w-8 h-8" />
              <span className="font-bold">50 Prize Pool</span>
            </div>
          </div>

          <div className="mb-8">
            <img
              src="https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?auto=format&fit=crop&q=80&w=2000"
              alt="Daily Lottery"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>

          <div className="mb-8">
            <p className="text-center text-yellow-400 mb-4">Time Left To Play</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(dailyTimeLeft.hours)}</div>
                <div className="text-sm text-gray-400">Hours</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(dailyTimeLeft.minutes)}</div>
                <div className="text-sm text-gray-400">Minutes</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(dailyTimeLeft.seconds)}</div>
                <div className="text-sm text-gray-400">Seconds</div>
              </div>
            </div>
          </div>

          <div className="text-center">
            <Link
              to="/entry"
              className={`inline-block px-8 py-3 rounded-full font-bold ${
                dailyExpired
                  ? 'bg-gray-600 cursor-not-allowed'
                  : 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-black hover:from-yellow-500 hover:to-yellow-600 transform hover:scale-105 transition-all'
              }`}
            >
              {dailyExpired ? 'Entry Closed' : 'Play Now'}
            </Link>
          </div>
        </div>
      )}

      {/* Daily Raffle */}
      {showDaily && (
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-4">Daily Raffle</h1>
            <div className="flex justify-center items-center space-x-2 text-yellow-400 text-2xl mb-6">
              <DollarSign className="w-8 h-8" />
              <span className="font-bold">50 Prize Pool</span>
            </div>
          </div>

          <div className="mb-8">
            <img
              src="https://images.unsplash.com/photo-1560472355-536de3962603?auto=format&fit=crop&q=80&w=2000"
              alt="Daily Raffle"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>

          <div className="mb-8">
            <p className="text-center text-yellow-400 mb-4">Time Left To Play</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(dailyTimeLeft.hours)}</div>
                <div className="text-sm text-gray-400">Hours</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(dailyTimeLeft.minutes)}</div>
                <div className="text-sm text-gray-400">Minutes</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(dailyTimeLeft.seconds)}</div>
                <div className="text-sm text-gray-400">Seconds</div>
              </div>
            </div>
          </div>

          <div className="text-center">
            <Link
              to="/daily-raffle"
              className={`inline-block px-8 py-3 rounded-full font-bold ${
                dailyExpired
                  ? 'bg-gray-600 cursor-not-allowed'
                  : 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-black hover:from-yellow-500 hover:to-yellow-600 transform hover:scale-105 transition-all'
              }`}
            >
              {dailyExpired ? 'Entry Closed' : 'Play Now'}
            </Link>
          </div>
        </div>
      )}

      {/* Weekly Lottery */}
      {showWeekly && (
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-4">Weekly Lottery</h1>
            <div className="flex justify-center items-center space-x-2 text-yellow-400 text-2xl mb-6">
              <DollarSign className="w-8 h-8" />
              <span className="font-bold">500 Prize Pool</span>
            </div>
          </div>

          <div className="mb-8">
            <img
              src="https://images.unsplash.com/photo-1560472355-536de3962603?auto=format&fit=crop&q=80&w=2000"
              alt="Weekly Lottery"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>

          <div className="mb-8">
            <p className="text-center text-yellow-400 mb-4">Time Left To Play</p>
            <div className="grid grid-cols-4 gap-4 max-w-xl mx-auto">
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{weeklyTimeLeft.days}</div>
                <div className="text-sm text-gray-400">Days</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(weeklyTimeLeft.hours)}</div>
                <div className="text-sm text-gray-400">Hours</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(weeklyTimeLeft.minutes)}</div>
                <div className="text-sm text-gray-400">Minutes</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(weeklyTimeLeft.seconds)}</div>
                <div className="text-sm text-gray-400">Seconds</div>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center gap-6">
            <div className="relative">
              <Circle className={`w-16 h-16 ${dailyRaffleProgress >= 4 ? 'text-green-500' : 'text-red-500'}`} />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-lg font-bold">{dailyRaffleProgress}/4</span>
              </div>
            </div>

            <Link
              to="/weekly-entry"
              className={`inline-block px-8 py-3 rounded-full font-bold ${
                dailyRaffleProgress < 4 || weeklyExpired
                  ? 'bg-gray-600 cursor-not-allowed'
                  : 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-black hover:from-yellow-500 hover:to-yellow-600 transform hover:scale-105 transition-all'
              }`}
            >
              {dailyRaffleProgress < 4 
                ? 'Complete Daily Entries First'
                : weeklyExpired 
                ? 'Entry Closed' 
                : 'Play Now'}
            </Link>
          </div>
        </div>
      )}

      {/* Weekly Raffle */}
      {showWeekly && (
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-4">Weekly Raffle</h1>
            <div className="flex justify-center items-center space-x-2 text-yellow-400 text-2xl mb-6">
              <DollarSign className="w-8 h-8" />
              <span className="font-bold">500 Prize Pool</span>
            </div>
          </div>

          <div className="mb-8">
            <img
              src="https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?auto=format&fit=crop&q=80&w=2000"
              alt="Weekly Raffle"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>

          <div className="mb-8">
            <p className="text-center text-yellow-400 mb-4">Time Left To Play</p>
            <div className="grid grid-cols-4 gap-4 max-w-xl mx-auto">
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{weeklyTimeLeft.days}</div>
                <div className="text-sm text-gray-400">Days</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(weeklyTimeLeft.hours)}</div>
                <div className="text-sm text-gray-400">Hours</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(weeklyTimeLeft.minutes)}</div>
                <div className="text-sm text-gray-400">Minutes</div>
              </div>
              <div className="bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center">
                <div className="text-3xl font-bold">{formatTime(weeklyTimeLeft.seconds)}</div>
                <div className="text-sm text-gray-400">Seconds</div>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center gap-6">
            <div className="relative">
              <Circle className={`w-16 h-16 ${dailyRaffleProgress >= 4 ? 'text-green-500' : 'text-red-500'}`} />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-lg font-bold">{dailyRaffleProgress}/4</span>
              </div>
            </div>

            <Link
              to="/weekly-raffle"
              className={`inline-block px-8 py-3 rounded-full font-bold ${
                dailyRaffleProgress < 4 || weeklyExpired
                  ? 'bg-gray-600 cursor-not-allowed'
                  : 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-black hover:from-yellow-500 hover:to-yellow-600 transform hover:scale-105 transition-all'
              }`}
            >
              {dailyRaffleProgress < 4 
                ? 'Complete Daily Entries First'
                : weeklyExpired 
                ? 'Entry Closed' 
                : 'Play Now'}
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}