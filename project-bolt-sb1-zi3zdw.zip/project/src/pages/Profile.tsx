import { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Wallet, Lock, User, History, Camera, Check, X, Trash2, Mail, Edit2, Eye, EyeOff } from 'lucide-react';
import TwoFactorAuth from '../components/TwoFactorAuth';
import { useUsernameValidation } from '../utils/usernameValidation';

export default function Profile() {
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [ethAddress, setEthAddress] = useState('');
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [newEthAddress, setNewEthAddress] = useState('');
  const [showEthAddress, setShowEthAddress] = useState(false);
  const [editingUsername, setEditingUsername] = useState(false);
  const [username, setUsername] = useState('@johndoe');
  const [newUsername, setNewUsername] = useState('@johndoe');
  const [editingEmail, setEditingEmail] = useState(false);
  const [email, setEmail] = useState('john.doe@example.com');
  const [newEmail, setNewEmail] = useState('john.doe@example.com');
  const [emailError, setEmailError] = useState('');
  const [is2FAEnabled, setIs2FAEnabled] = useState(false);
  const [connectionError, setConnectionError] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const {
    isChecking,
    usernameError,
    isAvailable,
    validateUsername
  } = useUsernameValidation();

  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!re.test(email)) {
      setEmailError('Please enter a valid email address');
      return false;
    }
    setEmailError('');
    return true;
  };

  const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/[^a-zA-Z0-9._]/g, '');
    
    if (value) {
      value = '@' + value;
    }

    setNewUsername(value);
    validateUsername(value);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeProfileImage = () => {
    setProfileImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    // API call would go here
    console.log('Password updated');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
  };

  const validateEthAddress = (address: string) => {
    return /^0x[a-fA-F0-9]{40}$/.test(address);
  };

  const saveEthAddress = () => {
    if (validateEthAddress(newEthAddress)) {
      setEthAddress(newEthAddress);
      setIsEditingAddress(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto text-white">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
        <div className="text-center mb-8">
          <div className="relative w-24 h-24 mx-auto mb-4">
            <div className={`w-full h-full rounded-full overflow-hidden ${
              profileImage ? '' : 'bg-gradient-to-br from-purple-400 to-purple-600'
            }`}>
              {profileImage ? (
                <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <span className="text-3xl font-bold">JD</span>
                </div>
              )}
            </div>
            <div className="absolute bottom-0 right-0 flex space-x-1">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="bg-yellow-400 text-black p-2 rounded-full hover:bg-yellow-500"
              >
                <Camera className="w-4 h-4" />
              </button>
              {profileImage && (
                <button
                  onClick={removeProfileImage}
                  className="bg-red-500 text-white p-2 rounded-full hover:bg-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageUpload}
              accept="image/*"
              className="hidden"
            />
          </div>

          {editingUsername ? (
            <div className="mb-4">
              <div className="relative">
                <input
                  type="text"
                  value={newUsername}
                  onChange={handleUsernameChange}
                  className="w-full bg-black/20 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
                {newUsername && (
                  <div className="absolute right-3 top-2.5">
                    {isChecking && (
                      <div className="w-5 h-5 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin" />
                    )}
                    {!isChecking && isAvailable === true && (
                      <Check className="w-5 h-5 text-green-500" />
                    )}
                    {!isChecking && isAvailable === false && (
                      <X className="w-5 h-5 text-red-500" />
                    )}
                  </div>
                )}
              </div>
              {usernameError && <p className="text-red-500 text-sm mt-1">{usernameError}</p>}
              {!usernameError && isAvailable === true && (
                <p className="text-green-500 text-sm mt-1">Username is available</p>
              )}
              {!usernameError && isAvailable === false && (
                <p className="text-red-500 text-sm mt-1">Username is already taken</p>
              )}
              <div className="flex justify-center space-x-2 mt-2">
                <button
                  onClick={() => {
                    if (isAvailable) {
                      setUsername(newUsername);
                      setEditingUsername(false);
                    }
                  }}
                  disabled={!isAvailable || !!usernameError}
                  className="bg-yellow-400 text-black px-4 py-1 rounded-lg hover:bg-yellow-500 disabled:bg-gray-600 disabled:cursor-not-allowed"
                >
                  Save
                </button>
                <button
                  onClick={() => {
                    setEditingUsername(false);
                    setNewUsername(username);
                  }}
                  className="bg-red-600 px-4 py-1 rounded-lg hover:bg-red-700"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center space-x-2 mb-4">
              <h1 className="text-2xl font-bold">{username}</h1>
              <button
                onClick={() => setEditingUsername(true)}
                className="text-yellow-400 hover:text-yellow-500"
              >
                <Edit2 className="w-4 h-4" />
              </button>
            </div>
          )}

          {editingEmail ? (
            <div className="mb-4">
              <div className="relative">
                <input
                  type="email"
                  value={newEmail}
                  onChange={(e) => {
                    setNewEmail(e.target.value);
                    validateEmail(e.target.value);
                  }}
                  className="w-full bg-black/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
              </div>
              {emailError && <p className="text-red-500 text-sm mt-1">{emailError}</p>}
              <div className="flex justify-center space-x-2 mt-2">
                <button
                  onClick={() => {
                    if (validateEmail(newEmail)) {
                      setEmail(newEmail);
                      setEditingEmail(false);
                    }
                  }}
                  disabled={!!emailError}
                  className="bg-yellow-400 text-black px-4 py-1 rounded-lg hover:bg-yellow-500 disabled:bg-gray-600 disabled:cursor-not-allowed"
                >
                  Save
                </button>
                <button
                  onClick={() => {
                    setEditingEmail(false);
                    setNewEmail(email);
                  }}
                  className="bg-red-600 px-4 py-1 rounded-lg hover:bg-red-700"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center space-x-2">
              <p className="text-gray-400">{email}</p>
              <button
                onClick={() => setEditingEmail(true)}
                className="text-yellow-400 hover:text-yellow-500"
              >
                <Edit2 className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="bg-black/20 rounded-xl p-4">
            <div className="flex items-center space-x-2 mb-4">
              <Lock className="w-5 h-5 text-yellow-400" />
              <span className="font-semibold">Change Password</span>
            </div>
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div className="relative">
                <input
                  type={showCurrentPassword ? "text" : "password"}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Current Password"
                  className="w-full bg-black/20 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  className="absolute right-3 top-2.5 text-gray-400"
                >
                  {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              <div className="relative">
                <input
                  type={showNewPassword ? "text" : "password"}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="New Password"
                  className="w-full bg-black/20 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3 top-2.5 text-gray-400"
                >
                  {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              <div className="relative">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm New Password"
                  className="w-full bg-black/20 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-2.5 text-gray-400"
                >
                  {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              <button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-700 py-2 rounded-lg font-semibold"
              >
                Update Password
              </button>
            </form>
          </div>

          <div className="bg-black/20 rounded-xl p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Wallet className="w-5 h-5 text-yellow-400" />
                <span className="font-semibold">MetaMask Wallet</span>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setIsEditingAddress(!isEditingAddress)}
                  className="text-yellow-400 hover:text-yellow-500"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                {!isConnected && (
                  <button
                    onClick={() => setIsConnected(true)}
                    className="bg-yellow-400 text-black px-4 py-2 rounded-lg hover:bg-yellow-500"
                  >
                    Connect
                  </button>
                )}
              </div>
            </div>
            {connectionError && (
              <p className="text-red-500 text-sm mb-2">{connectionError}</p>
            )}
            {isConnected ? (
              <div className="relative">
                <input
                  type={showEthAddress ? "text" : "password"}
                  value={ethAddress}
                  readOnly
                  className="w-full bg-black/20 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-yellow-400 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowEthAddress(!showEthAddress)}
                  className="absolute right-3 top-2.5 text-gray-400"
                >
                  {showEthAddress ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {isEditingAddress && (
                  <div>
                    <div className="relative">
                      <input
                        type={showEthAddress ? "text" : "password"}
                        value={newEthAddress}
                        onChange={(e) => setNewEthAddress(e.target.value)}
                        placeholder="Enter ETH address only"
                        className="w-full bg-black/20 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-yellow-400 font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowEthAddress(!showEthAddress)}
                        className="absolute right-3 top-2.5 text-gray-400"
                      >
                        {showEthAddress ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                    <div className="flex justify-end space-x-2 mt-2">
                      <button
                        onClick={saveEthAddress}
                        disabled={!validateEthAddress(newEthAddress)}
                        className="bg-yellow-400 text-black px-4 py-1 rounded-lg hover:bg-yellow-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-sm"
                      >
                        Save
                      </button>
                      <button
                        onClick={() => {
                          setIsEditingAddress(false);
                          setNewEthAddress('');
                        }}
                        className="bg-red-600 px-4 py-1 rounded-lg hover:bg-red-700 text-sm"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="bg-black/20 rounded-xl p-4">
            <TwoFactorAuth
              isEnabled={is2FAEnabled}
              onEnable={() => setIs2FAEnabled(true)}
              onDisable={() => setIs2FAEnabled(false)}
            />
          </div>

          <Link
            to="/lottery-history"
            className="block bg-black/20 rounded-xl p-4 hover:bg-black/30"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <History className="w-5 h-5 text-yellow-400" />
                <span className="font-semibold">Lottery History</span>
              </div>
              <div className="text-gray-400">
                View all entries →
              </div>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}