import { useState } from 'react';
import { Link } from 'react-router-dom';
import { UserPlus, X as Close } from 'lucide-react';
import PasswordInput from '../components/PasswordInput';
import { usePasswordValidation } from '../hooks/usePasswordValidation';

export default function Signup() {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [usernameError, setUsernameError] = useState('');

  const {
    passwordError,
    confirmPasswordError,
    validatePassword,
    validatePasswordMatch,
  } = usePasswordValidation();

  const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/[^a-zA-Z0-9]/g, '');
    
    if (value.length > 20) {
      value = value.slice(0, 20);
    }

    if (value) {
      value = '@' + value;
    }

    setUsername(value);
    setUsernameError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Show validation feedback
    validatePassword(password);
    validatePasswordMatch(password, confirmPassword);
    
    // Proceed with signup
    try {
      // API call would go here
      console.log('Account created');
    } catch (error) {
      console.error('Failed to create account:', error);
    }
  };

  return (
    <div className="max-w-md mx-auto text-white">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
        <div className="text-center mb-8">
          <UserPlus className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
          <h1 className="text-3xl font-bold">Create Account</h1>
          <p className="text-gray-400">Join the lucky community today</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name"
            className="w-full bg-black/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />

          <input
            type="text"
            value={username}
            onChange={handleUsernameChange}
            placeholder="Username"
            className="w-full bg-black/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />
          {usernameError && <p className="text-red-500 text-sm mt-1">{usernameError}</p>}

          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            className="w-full bg-black/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />

          <PasswordInput
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              validatePassword(e.target.value);
              if (confirmPassword) {
                validatePasswordMatch(e.target.value, confirmPassword);
              }
            }}
            placeholder="Password"
            error={passwordError}
          />

          <PasswordInput
            value={confirmPassword}
            onChange={(e) => {
              setConfirmPassword(e.target.value);
              validatePasswordMatch(password, e.target.value);
            }}
            placeholder="Confirm Password"
            error={confirmPasswordError}
          />

          <div className="flex items-center">
            <input
              type="checkbox"
              id="terms"
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
              className="w-4 h-4 rounded-full border-2 border-yellow-400 text-yellow-400 focus:ring-yellow-400 focus:ring-offset-0 focus:ring-offset-transparent"
            />
            <label htmlFor="terms" className="ml-2 text-sm text-gray-400">
              I agree to the{' '}
              <button
                type="button"
                onClick={() => setShowTerms(true)}
                className="text-yellow-400 hover:underline"
              >
                Terms and Conditions
              </button>
            </label>
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 text-black font-bold py-3 rounded-lg hover:from-yellow-500 hover:to-yellow-600"
          >
            Create Account
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-gray-400">
            Already have an account?{' '}
            <Link to="/login" className="text-yellow-400 hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </div>

      {/* Terms Modal */}
      {showTerms && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 rounded-2xl p-8 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Terms and Conditions</h2>
              <button
                onClick={() => setShowTerms(false)}
                className="text-gray-400 hover:text-white"
              >
                <Close className="w-6 h-6" />
              </button>
            </div>
            
            <div className="space-y-4 text-gray-300">
              <h3 className="text-xl font-semibold text-white">1. Acceptance of Terms</h3>
              <p>
                By accessing and using LuckyDraw, you agree to be bound by these Terms and Conditions
                and all applicable laws and regulations.
              </p>

              <h3 className="text-xl font-semibold text-white">2. Eligibility</h3>
              <p>
                You must be at least 18 years old to use our services. By participating, you confirm
                that you meet the minimum age requirement and are legally able to participate in
                lottery activities in your jurisdiction.
              </p>

              <h3 className="text-xl font-semibold text-white">3. Account Security</h3>
              <p>
                You are responsible for maintaining the confidentiality of your account credentials
                and for all activities that occur under your account.
              </p>

              <h3 className="text-xl font-semibold text-white">4. Prize Claims</h3>
              <p>
                Winners must claim their prizes within the specified timeframe. Unclaimed prizes will
                be forfeited according to our prize claim policy.
              </p>

              <h3 className="text-xl font-semibold text-white">5. Fair Play</h3>
              <p>
                Any form of cheating, exploitation, or manipulation of the lottery system is strictly
                prohibited and will result in immediate account termination.
              </p>

              <h3 className="text-xl font-semibold text-white">6. Privacy</h3>
              <p>
                Your privacy is important to us. We collect and process your data in accordance with
                our Privacy Policy, which is incorporated into these Terms by reference.
              </p>

              <h3 className="text-xl font-semibold text-white">7. Modifications</h3>
              <p>
                We reserve the right to modify these Terms at any time. Continued use of the service
                after changes constitutes acceptance of the modified Terms.
              </p>

              <h3 className="text-xl font-semibold text-white">8. Termination</h3>
              <p>
                We reserve the right to terminate or suspend your account at our discretion, without
                notice, for conduct that we believe violates these Terms or is harmful to other users.
              </p>

              <h3 className="text-xl font-semibold text-white">9. Limitation of Liability</h3>
              <p>
                LuckyDraw is not liable for any indirect, incidental, special, consequential, or
                punitive damages resulting from your use or inability to use the service.
              </p>

              <h3 className="text-xl font-semibold text-white">10. Contact</h3>
              <p>
                If you have any questions about these Terms, please contact us at support@luckydraw.com
              </p>
            </div>

            <div className="mt-8 flex justify-end">
              <button
                onClick={() => setShowTerms(false)}
                className="bg-yellow-400 text-black px-6 py-2 rounded-lg hover:bg-yellow-500"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}