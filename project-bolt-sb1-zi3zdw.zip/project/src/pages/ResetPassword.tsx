import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, Eye, EyeOff } from 'lucide-react';
import { validatePassword, validatePasswordMatch } from '../utils/passwordValidation';

export default function ResetPassword() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');
  const [resendTimer, setResendTimer] = useState(60);
  const [canResend, setCanResend] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [codeSent, setCodeSent] = useState(true);
  const [verificationError, setVerificationError] = useState('');

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendTimer > 0 && !canResend) {
      timer = setInterval(() => {
        setResendTimer((prev) => prev - 1);
      }, 1000);
    } else {
      setCanResend(true);
    }
    return () => clearInterval(timer);
  }, [resendTimer, canResend]);

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPassword = e.target.value;
    setPassword(newPassword);
    const validation = validatePassword(newPassword);
    setPasswordError(validation.error);
    if (confirmPassword) {
      setConfirmPasswordError(validatePasswordMatch(newPassword, confirmPassword));
    }
  };

  const handleConfirmPasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newConfirmPassword = e.target.value;
    setConfirmPassword(newConfirmPassword);
    setConfirmPasswordError(validatePasswordMatch(password, newConfirmPassword));
  };

  const handleResendCode = () => {
    if (!canResend) return;
    setResendTimer(60);
    setCanResend(false);
    setCodeSent(true);
    // Mock API call to resend verification code
  };

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (verificationCode.length !== 6) {
      setVerificationError('Please enter a valid 6-digit code');
      return;
    }
    setVerificationError('');
    setCodeSent(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const passwordValidation = validatePassword(password);
    const matchValidation = validatePasswordMatch(password, confirmPassword);
    
    if (!passwordValidation.isValid || matchValidation) {
      setPasswordError(passwordValidation.error);
      setConfirmPasswordError(matchValidation);
      return;
    }

    // Mock API call - replace with actual API call
    navigate('/login');
  };

  return (
    <div className="max-w-md mx-auto text-white">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
        <div className="text-center mb-8">
          <Lock className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
          <h1 className="text-3xl font-bold">Reset Password</h1>
          <p className="text-gray-400">
            {codeSent 
              ? "Enter the 6-digit code sent to your email"
              : "Create your new password"
            }
          </p>
        </div>

        {codeSent ? (
          <form onSubmit={handleVerifyCode} className="space-y-6">
            <div>
              <input
                type="text"
                value={verificationCode}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                  setVerificationCode(value);
                  setVerificationError('');
                }}
                placeholder="Enter 6-digit code"
                className="w-full bg-black/20 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-400 text-center text-2xl tracking-wider"
                required
              />
              {verificationError && (
                <p className="text-red-500 text-sm mt-2">{verificationError}</p>
              )}
            </div>

            <div className="text-center">
              <button
                type="button"
                onClick={handleResendCode}
                disabled={!canResend}
                className="text-yellow-400 hover:text-yellow-500 disabled:text-gray-500"
              >
                {canResend 
                  ? "Didn't receive verification code? Send again" 
                  : `Send verification code again in ${resendTimer}s`}
              </button>
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 text-black font-bold py-3 rounded-lg hover:from-yellow-500 hover:to-yellow-600"
            >
              Verify Code
            </button>
          </form>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={handlePasswordChange}
                  placeholder="New Password"
                  className="w-full bg-black/20 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-gray-400"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              {passwordError && (
                <p className="text-red-500 text-sm mt-2">{passwordError}</p>
              )}
            </div>

            <div>
              <div className="relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={handleConfirmPasswordChange}
                  placeholder="Confirm New Password"
                  className="w-full bg-black/20 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-3 text-gray-400"
                >
                  {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              {confirmPasswordError && (
                <p className="text-red-500 text-sm mt-2">{confirmPasswordError}</p>
              )}
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 text-black font-bold py-3 rounded-lg hover:from-yellow-500 hover:to-yellow-600"
            >
              Reset Password
            </button>
          </form>
        )}
      </div>
    </div>
  );
}