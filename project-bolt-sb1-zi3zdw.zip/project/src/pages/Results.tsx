import { useState } from 'react';
import { Calendar } from 'lucide-react';

export default function Results() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  
  // Mock data - in a real app, this would be fetched based on the selected date
  const results = [
    {
      type: 'Daily Lottery',
      winningNumbers: [7, 13, 24, 35, 46, 71],
      prizePool: 50
    },
    {
      type: 'Weekly Lottery',
      winningNumbers: [3, 11, 22, 33, 44, 55],
      prizePool: 500
    },
    {
      type: 'Daily Raffle',
      winningNumber: 87,
      prizePool: 50
    },
    {
      type: 'Weekly Raffle',
      winningNumber: 123,
      prizePool: 500
    }
  ];
  
  return (
    <div className="max-w-4xl mx-auto text-white">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-4">Latest Results</h1>
          
          <div className="max-w-xs mx-auto">
            <div className="relative">
              <Calendar className="absolute left-3 top-3 w-5 h-5 text-yellow-400" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full bg-black/20 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-400 text-white"
              />
            </div>
          </div>
        </div>

        <div className="space-y-8">
          {results.map((result, index) => (
            <div key={index} className="bg-black/20 rounded-xl p-6">
              <h2 className="text-2xl font-bold mb-4 text-center">{result.type}</h2>
              
              {'winningNumbers' in result ? (
                <div className="flex justify-center space-x-4 mb-8">
                  {result.winningNumbers.map((num, idx) => (
                    <div
                      key={idx}
                      className="w-16 h-16 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center"
                    >
                      <span className="text-2xl font-bold text-black">{num}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center mb-8">
                  <div className="text-lg text-gray-400 mb-2">Winning Number</div>
                  <div className="text-4xl font-bold text-yellow-400">#{result.winningNumber}</div>
                </div>
              )}

              <div className="text-center">
                <p className="text-xl mb-2">Prize Pool</p>
                <p className="text-3xl font-bold text-yellow-400">${result.prizePool.toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}