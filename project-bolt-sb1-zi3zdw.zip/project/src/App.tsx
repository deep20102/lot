import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Entry from './pages/Entry';
import WeeklyEntry from './pages/WeeklyEntry';
import DailyRaffle from './pages/DailyRaffle';
import WeeklyRaffle from './pages/WeeklyRaffle';
import Results from './pages/Results';
import Profile from './pages/Profile';
import LotteryHistory from './pages/LotteryHistory';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex flex-col">
        <Navbar />
        <main className="container mx-auto px-4 py-8 flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/entry" element={<Entry />} />
            <Route path="/weekly-entry" element={<WeeklyEntry />} />
            <Route path="/daily-raffle" element={<DailyRaffle />} />
            <Route path="/weekly-raffle" element={<WeeklyRaffle />} />
            <Route path="/results" element={<Results />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/lottery-history" element={<LotteryHistory />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}