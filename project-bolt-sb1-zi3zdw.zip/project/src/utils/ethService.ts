interface TransferResult {
  success: boolean;
  transactionHash?: string;
  error?: string;
}

export const transferPrize = async (
  winnerAddress: string,
  amount: number
): Promise<TransferResult> => {
  try {
    // In a real app, this would interact with your smart contract
    // Mock successful transfer
    const hash = `0x${Array(64).fill(0).map(() => 
      Math.floor(Math.random() * 16).toString(16)
    ).join('')}`;

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    return {
      success: true,
      transactionHash: hash
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Transfer failed'
    };
  }
};

export const validateEthAddress = (address: string): boolean => {
  return /^0x[a-fA-F0-9]{40}$/.test(address);
};