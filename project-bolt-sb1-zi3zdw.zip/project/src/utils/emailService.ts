import { DrawResult } from '../store/useDrawResultsStore';

export const sendWinningEmail = async (
  email: string,
  result: DrawResult
) => {
  // In a real app, this would call your email service API
  console.log(`Sending winning notification email to ${email}`, {
    type: result.type,
    prizeAmount: result.prizeAmount,
    claimDeadline: result.winner.claimDeadline,
    message: `Congratulations! You've won ${result.prizeAmount} in the ${result.type}. 
              Please add your ETH address within 7 days to claim your prize.`
  });
};

export const sendClaimReminderEmail = async (
  email: string,
  result: DrawResult
) => {
  // In a real app, this would call your email service API
  console.log(`Sending claim reminder email to ${email}`, {
    type: result.type,
    prizeAmount: result.prizeAmount,
    claimDeadline: result.winner.claimDeadline,
    message: `Don't forget to claim your prize of ${result.prizeAmount} from the ${result.type}. 
              Add your ETH address before ${result.winner.claimDeadline} to receive your prize.`
  });
};