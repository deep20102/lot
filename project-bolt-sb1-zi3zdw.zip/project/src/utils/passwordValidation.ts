export const validatePassword = (password: string): { isValid: boolean; error: string } => {
  if (password.length < 8) {
    return { isValid: false, error: 'Password must be at least 8 characters' };
  }
  if (!/[A-Z]/.test(password)) {
    return { isValid: false, error: 'Password must contain an uppercase letter' };
  }
  if (!/[a-z]/.test(password)) {
    return { isValid: false, error: 'Password must contain a lowercase letter' };
  }
  if (!/[0-9]/.test(password)) {
    return { isValid: false, error: 'Password must contain a number' };
  }
  if (!/[!@#$%^&*]/.test(password)) {
    return { isValid: false, error: 'Password must contain a special character' };
  }
  return { isValid: true, error: '' };
};

export const validatePasswordMatch = (password: string, confirmPassword: string): string => {
  return password !== confirmPassword ? 'Passwords do not match' : '';
};