import { useState } from 'react';

// Mock database of usernames
const takenUsernames = new Set(['@john', '@jane', '@admin']);

export const useUsernameValidation = () => {
  const [isChecking, setIsChecking] = useState(false);
  const [usernameError, setUsernameError] = useState('');
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null);

  const validateUsername = async (username: string) => {
    if (!username) {
      setUsernameError('');
      setIsAvailable(null);
      return;
    }

    const usernameWithoutAt = username.slice(1);
    
    // Check for valid characters
    if (!/^[@]?[a-zA-Z0-9][a-zA-Z0-9._]*[a-zA-Z0-9]$/.test(username)) {
      setUsernameError('Username can only contain letters, numbers, dots, and underscores');
      setIsAvailable(null);
      return;
    }

    if (usernameWithoutAt.length > 20) {
      setUsernameError('Username cannot exceed 20 characters');
      setIsAvailable(null);
      return;
    }

    setUsernameError('');
    setIsChecking(true);

    // Simulate API call to check username availability
    await new Promise(resolve => setTimeout(resolve, 500));
    const available = !takenUsernames.has(username);
    
    setIsChecking(false);
    setIsAvailable(available);
  };

  return {
    isChecking,
    usernameError,
    isAvailable,
    validateUsername,
    setUsernameError,
    setIsAvailable
  };
};