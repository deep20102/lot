import { useState, useEffect } from 'react';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export function useTimer(endTime: Date) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [isExpired, setIsExpired] = useState(false);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = endTime.getTime() - new Date().getTime();
      
      if (difference <= 0) {
        setIsExpired(true);
        return { days: 0, hours: 0, minutes: 0, seconds: 0 };
      }

      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60)
      };
    };

    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(timer);
  }, [endTime]);

  return { timeLeft, isExpired };
}

export function getNextDailyEndTime() {
  const now = new Date();
  const endTime = new Date(now);
  endTime.setUTCHours(23, 55, 0, 0);
  
  if (now > endTime) {
    endTime.setDate(endTime.getDate() + 1);
  }
  
  return endTime;
}

export function getWeeklyEndTime() {
  const now = new Date();
  const endTime = new Date(now);
  
  // Set to next Sunday 23:55 UTC
  const daysUntilSunday = 7 - endTime.getUTCDay();
  endTime.setUTCDate(endTime.getUTCDate() + daysUntilSunday);
  endTime.setUTCHours(23, 55, 0, 0);
  
  return endTime;
}

export function isLotteryVisible() {
  const now = new Date();
  const currentHour = now.getUTCHours();
  const currentMinute = now.getUTCMinutes();
  
  // Visible from 00:00:00 to 23:59:00 UTC
  return currentHour < 23 || (currentHour === 23 && currentMinute < 59);
}

export function isWeeklyLotteryVisible() {
  const now = new Date();
  const currentDay = now.getUTCDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
  const currentHour = now.getUTCHours();
  const currentMinute = now.getUTCMinutes();
  
  // Not visible on Sunday after 23:59
  if (currentDay === 0 && (currentHour === 23 && currentMinute >= 59)) {
    return false;
  }
  
  return true;
}