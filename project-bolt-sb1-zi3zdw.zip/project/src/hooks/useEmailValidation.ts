// Mock database of registered emails
const registeredEmails = new Set(['test@example.com', 'user@example.com']);

export const useEmailValidation = () => {
  const checkEmailExists = async (email: string): Promise<boolean> => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));
    return registeredEmails.has(email.toLowerCase());
  };

  const validateEmail = (email: string): boolean => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  return {
    checkEmailExists,
    validateEmail
  };
};