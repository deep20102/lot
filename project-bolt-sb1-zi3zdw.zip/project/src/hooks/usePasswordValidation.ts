import { useState } from 'react';

export const usePasswordValidation = () => {
  const [passwordError, setPasswordError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');

  const validatePassword = (password: string) => {
    if (password.length < 8) {
      setPasswordError('Password must be at least 8 characters');
      return false;
    }
    if (!/[A-Z]/.test(password)) {
      setPasswordError('Password must contain an uppercase letter');
      return false;
    }
    if (!/[a-z]/.test(password)) {
      setPasswordError('Password must contain a lowercase letter');
      return false;
    }
    if (!/[0-9]/.test(password)) {
      setPasswordError('Password must contain a number');
      return false;
    }
    if (!/[!@#$%^&*]/.test(password)) {
      setPasswordError('Password must contain a special character');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const validatePasswordMatch = (password: string, confirmPassword: string) => {
    if (password !== confirmPassword) {
      setConfirmPasswordError('Passwords do not match');
      return false;
    }
    setConfirmPasswordError('');
    return true;
  };

  return {
    passwordError,
    confirmPasswordError,
    validatePassword,
    validatePasswordMatch,
    setPasswordError,
    setConfirmPasswordError
  };
};