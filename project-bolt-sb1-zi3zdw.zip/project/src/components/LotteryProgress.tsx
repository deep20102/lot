import { Circle } from 'lucide-react';

interface LotteryProgressProps {
  played: number;
  required: number;
}

export default function LotteryProgress({ played, required }: LotteryProgressProps) {
  return (
    <div className="flex items-center justify-center">
      <div className="relative">
        <Circle
          className={`w-8 h-8 ${
            played >= required ? 'text-green-500' : 'text-red-500'
          }`}
        />
        <span className="absolute inset-0 flex items-center justify-center text-white text-sm font-bold">
          {played}/{required}
        </span>
      </div>
    </div>
  );
}