import { Wallet, Edit2, Eye, EyeOff } from 'lucide-react';

interface WalletSectionProps {
  isConnected: boolean;
  ethAddress: string;
  isEditingAddress: boolean;
  newEthAddress: string;
  showEthAddress: boolean;
  connectionError: string;
  onConnect: () => Promise<void>;
  onSaveAddress: () => void;
  setIsEditingAddress: (value: boolean) => void;
  setNewEthAddress: (value: string) => void;
  setShowEthAddress: (value: boolean) => void;
}

export default function WalletSection({
  isConnected,
  ethAddress,
  isEditingAddress,
  newEthAddress,
  showEthAddress,
  connectionError,
  onConnect,
  onSaveAddress,
  setIsEditingAddress,
  setNewEthAddress,
  setShowEthAddress,
}: WalletSectionProps) {
  const validateEthAddress = (address: string) => {
    return /^0x[a-fA-F0-9]{40}$/.test(address);
  };

  return (
    <div className="bg-black/20 rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Wallet className="w-5 h-5 text-yellow-400" />
          <span className="font-semibold">MetaMask Wallet</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsEditingAddress(!isEditingAddress)}
            className="text-yellow-400 hover:text-yellow-500"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          {!isConnected && (
            <button
              onClick={onConnect}
              className="bg-yellow-400 text-black px-4 py-2 rounded-lg hover:bg-yellow-500"
            >
              Connect
            </button>
          )}
        </div>
      </div>
      {connectionError && (
        <p className="text-red-500 text-sm mb-2">{connectionError}</p>
      )}
      {isConnected ? (
        <div className="relative">
          <input
            type={showEthAddress ? "text" : "password"}
            value={ethAddress}
            readOnly
            className="w-full bg-black/20 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-yellow-400 font-mono"
          />
          <button
            type="button"
            onClick={() => setShowEthAddress(!showEthAddress)}
            className="absolute right-3 top-2.5 text-gray-400"
          >
            {showEthAddress ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          {isEditingAddress && (
            <div>
              <div className="relative">
                <input
                  type={showEthAddress ? "text" : "password"}
                  value={newEthAddress}
                  onChange={(e) => setNewEthAddress(e.target.value)}
                  placeholder="Enter ETH address only"
                  className="w-full bg-black/20 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-yellow-400 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowEthAddress(!showEthAddress)}
                  className="absolute right-3 top-2.5 text-gray-400"
                >
                  {showEthAddress ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <div className="flex justify-end space-x-2 mt-2">
                <button
                  onClick={onSaveAddress}
                  disabled={!validateEthAddress(newEthAddress)}
                  className="bg-yellow-400 text-black px-4 py-1 rounded-lg hover:bg-yellow-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-sm"
                >
                  Save
                </button>
                <button
                  onClick={() => {
                    setIsEditingAddress(false);
                    setNewEthAddress('');
                  }}
                  className="bg-red-600 px-4 py-1 rounded-lg hover:bg-red-700 text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}