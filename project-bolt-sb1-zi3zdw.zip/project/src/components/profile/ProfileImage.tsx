import { useRef, useState } from 'react';
import { Camera, Trash2 } from 'lucide-react';

interface ProfileImageProps {
  profileImage: string | null;
  onImageUpload: (image: string) => void;
  onImageRemove: () => void;
}

export default function ProfileImage({ profileImage, onImageUpload, onImageRemove }: ProfileImageProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onImageUpload(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="relative w-24 h-24 mx-auto mb-6">
      <div className="w-full h-full rounded-full overflow-hidden bg-black/20">
        {profileImage ? (
          <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Camera className="w-8 h-8 text-gray-400" />
          </div>
        )}
      </div>
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImageUpload}
        className="hidden"
      />
      
      <div className="absolute -bottom-2 -right-2 flex space-x-2">
        <button
          onClick={() => fileInputRef.current?.click()}
          className="bg-purple-600 p-2 rounded-full hover:bg-purple-700"
        >
          <Camera className="w-4 h-4" />
        </button>
        {profileImage && (
          <button
            onClick={onImageRemove}
            className="bg-red-600 p-2 rounded-full hover:bg-red-700"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}