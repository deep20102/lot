import { useState } from 'react';
import { User, Mail, Edit2, Check, X } from 'lucide-react';

interface UserInfoSectionProps {
  username: string;
  email: string;
  onUsernameUpdate: (username: string) => void;
  onEmailUpdate: (email: string) => void;
}

export default function UserInfoSection({
  username,
  email,
  onUsernameUpdate,
  onEmailUpdate
}: UserInfoSectionProps) {
  const [editingUsername, setEditingUsername] = useState(false);
  const [newUsername, setNewUsername] = useState(username);
  const [usernameError, setUsernameError] = useState('');
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [editingEmail, setEditingEmail] = useState(false);
  const [newEmail, setNewEmail] = useState(email);
  const [emailError, setEmailError] = useState('');

  const checkUsername = (value: string) => {
    const usernameWithoutAt = value.slice(1);
    if (!/^[a-zA-Z0-9._]*$/.test(usernameWithoutAt)) {
      setUsernameError('Username can only contain letters, numbers, periods, and underscores');
      setUsernameAvailable(null);
      return;
    }
    
    if (usernameWithoutAt.length > 25) {
      setUsernameError('Username cannot exceed 25 characters');
      setUsernameAvailable(null);
      return;
    }
    
    setUsernameError('');
    
    if (usernameWithoutAt.length > 0) {
      setUsernameAvailable(null);
      setTimeout(() => {
        setUsernameAvailable(!['@jane'].includes(value));
      }, 500);
    } else {
      setUsernameAvailable(null);
    }
  };

  const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;
    if (!value.startsWith('@')) {
      value = '@' + value;
    }
    setNewUsername(value);
    checkUsername(value);
  };

  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!re.test(email)) {
      setEmailError('Please enter a valid email address');
      return false;
    }
    setEmailError('');
    return true;
  };

  const handleSaveUsername = () => {
    if (usernameAvailable && !usernameError) {
      onUsernameUpdate(newUsername);
      setEditingUsername(false);
    }
  };

  const handleSaveEmail = () => {
    if (validateEmail(newEmail)) {
      onEmailUpdate(newEmail);
      setEditingEmail(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-black/20 rounded-xl p-4">
        <div className="flex items-center space-x-2 mb-4">
          <User className="w-5 h-5 text-yellow-400" />
          <span className="font-semibold">Username</span>
        </div>
        {editingUsername ? (
          <div className="space-y-2">
            <div className="flex space-x-2">
              <input
                type="text"
                value={newUsername}
                onChange={handleUsernameChange}
                className="flex-1 bg-black/20 rounded-lg px-3 py-1 focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
              <button
                onClick={handleSaveUsername}
                disabled={!usernameAvailable || !!usernameError}
                className="bg-green-600 p-2 rounded-lg hover:bg-green-700 disabled:bg-gray-600"
              >
                <Check className="w-4 h-4" />
              </button>
              <button
                onClick={() => setEditingUsername(false)}
                className="bg-red-600 p-2 rounded-lg hover:bg-red-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {usernameError && <p className="text-red-500 text-sm">{usernameError}</p>}
            {!usernameError && usernameAvailable === null && newUsername.length > 1 && (
              <p className="text-yellow-400 text-sm">Checking availability...</p>
            )}
            {!usernameError && usernameAvailable === true && (
              <p className="text-green-500 text-sm">Username is available</p>
            )}
            {!usernameError && usernameAvailable === false && (
              <p className="text-red-500 text-sm">Username is already taken</p>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-between">
            <span>{username}</span>
            <Edit2
              className="w-4 h-4 text-gray-400 cursor-pointer hover:text-white"
              onClick={() => setEditingUsername(true)}
            />
          </div>
        )}
      </div>

      <div className="bg-black/20 rounded-xl p-4">
        <div className="flex items-center space-x-2 mb-4">
          <Mail className="w-5 h-5 text-yellow-400" />
          <span className="font-semibold">Email</span>
        </div>
        {editingEmail ? (
          <div className="space-y-2">
            <div className="flex space-x-2">
              <input
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="flex-1 bg-black/20 rounded-lg px-3 py-1 focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
              <button
                onClick={handleSaveEmail}
                className="bg-green-600 p-2 rounded-lg hover:bg-green-700"
              >
                <Check className="w-4 h-4" />
              </button>
              <button
                onClick={() => setEditingEmail(false)}
                className="bg-red-600 p-2 rounded-lg hover:bg-red-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {emailError && <p className="text-red-500 text-sm">{emailError}</p>}
          </div>
        ) : (
          <div className="flex items-center justify-between">
            <span>{email}</span>
            <Edit2
              className="w-4 h-4 text-gray-400 cursor-pointer hover:text-white"
              onClick={() => setEditingEmail(true)}
            />
          </div>
        )}
      </div>
    </div>
  );
}