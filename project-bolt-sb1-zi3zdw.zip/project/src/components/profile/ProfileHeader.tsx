import { useRef } from 'react';
import { Camera, Trash2, Edit2, Check, X } from 'lucide-react';

interface ProfileHeaderProps {
  profileImage: string | null;
  username: string;
  email: string;
  editingUsername: boolean;
  editingEmail: boolean;
  newUsername: string;
  newEmail: string;
  usernameError: string;
  emailError: string;
  usernameAvailable: boolean | null;
  onImageUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onImageRemove: () => void;
  onUsernameChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onEmailChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onSaveUsername: () => void;
  onSaveEmail: () => void;
  setEditingUsername: (value: boolean) => void;
  setEditingEmail: (value: boolean) => void;
  setNewUsername: (value: string) => void;
  setNewEmail: (value: string) => void;
}

export default function ProfileHeader({
  profileImage,
  username,
  email,
  editingUsername,
  editingEmail,
  newUsername,
  newEmail,
  usernameError,
  emailError,
  usernameAvailable,
  onImageUpload,
  onImageRemove,
  onUsernameChange,
  onEmailChange,
  onSaveUsername,
  onSaveEmail,
  setEditingUsername,
  setEditingEmail,
  setNewUsername,
  setNewEmail,
}: ProfileHeaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="text-center mb-8">
      <div className="relative w-24 h-24 mx-auto mb-4">
        <div className={`w-full h-full rounded-full overflow-hidden ${
          profileImage ? '' : 'bg-gradient-to-br from-purple-400 to-purple-600'
        }`}>
          {profileImage ? (
            <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <span className="text-3xl font-bold">JD</span>
            </div>
          )}
        </div>
        <div className="absolute bottom-0 right-0 flex space-x-1">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="bg-yellow-400 text-black p-2 rounded-full hover:bg-yellow-500"
          >
            <Camera className="w-4 h-4" />
          </button>
          {profileImage && (
            <button
              onClick={onImageRemove}
              className="bg-red-500 text-white p-2 rounded-full hover:bg-red-600"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
        <input
          type="file"
          ref={fileInputRef}
          onChange={onImageUpload}
          accept="image/*"
          className="hidden"
        />
      </div>
      
      {editingUsername ? (
        <div className="mb-4">
          <div className="relative">
            <input
              type="text"
              value={newUsername}
              onChange={onUsernameChange}
              className="w-full bg-black/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
            {newUsername.length > 1 && (
              <div className="absolute right-3 top-2">
                {usernameAvailable === true && <Check className="w-5 h-5 text-green-500" />}
                {usernameAvailable === false && <X className="w-5 h-5 text-red-500" />}
              </div>
            )}
          </div>
          {usernameError && <p className="text-red-500 text-sm mt-1">{usernameError}</p>}
          {!usernameError && usernameAvailable === true && <p className="text-green-500 text-sm mt-1">Username is available</p>}
          {!usernameError && usernameAvailable === false && <p className="text-red-500 text-sm mt-1">Username is already taken</p>}
          <div className="flex justify-center space-x-2 mt-2">
            <button
              onClick={onSaveUsername}
              disabled={!usernameAvailable || !!usernameError}
              className="bg-yellow-400 text-black px-4 py-1 rounded-lg hover:bg-yellow-500 disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
              Save
            </button>
            <button
              onClick={() => {
                setEditingUsername(false);
                setNewUsername(username);
              }}
              className="bg-red-600 px-4 py-1 rounded-lg hover:bg-red-700"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center space-x-2 mb-4">
          <h1 className="text-2xl font-bold">{username}</h1>
          <button
            onClick={() => setEditingUsername(true)}
            className="text-yellow-400 hover:text-yellow-500"
          >
            <Edit2 className="w-4 h-4" />
          </button>
        </div>
      )}

      {editingEmail ? (
        <div className="mb-4">
          <div className="relative">
            <input
              type="email"
              value={newEmail}
              onChange={onEmailChange}
              className="w-full bg-black/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
          </div>
          {emailError && <p className="text-red-500 text-sm mt-1">{emailError}</p>}
          <div className="flex justify-center space-x-2 mt-2">
            <button
              onClick={onSaveEmail}
              disabled={!!emailError}
              className="bg-yellow-400 text-black px-4 py-1 rounded-lg hover:bg-yellow-500 disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
              Save
            </button>
            <button
              onClick={() => {
                setEditingEmail(false);
                setNewEmail(email);
              }}
              className="bg-red-600 px-4 py-1 rounded-lg hover:bg-red-700"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center space-x-2">
          <p className="text-gray-400">{email}</p>
          <button
            onClick={() => setEditingEmail(true)}
            className="text-yellow-400 hover:text-yellow-500"
          >
            <Edit2 className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}