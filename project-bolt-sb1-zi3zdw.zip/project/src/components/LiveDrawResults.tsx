import { useEffect, useState } from 'react';
import { useDrawResultsStore } from '../store/useDrawResultsStore';
import { Clock, Trophy, ExternalLink, AlertTriangle } from 'lucide-react';
import { sendWinningEmail } from '../utils/emailService';
import { transferPrize } from '../utils/ethService';

export default function LiveDrawResults() {
  const { results, updateResult } = useDrawResultsStore();
  const [latestResults, setLatestResults] = useState(results);

  useEffect(() => {
    // In a real app, this would connect to a WebSocket for live updates
    const interval = setInterval(() => {
      setLatestResults(results);
      
      // Check for unclaimed prizes and process automatic transfers
      results.forEach(async (result) => {
        if (!result.winner.claimed && result.winner.ethAddress) {
          try {
            const transfer = await transferPrize(result.winner.ethAddress, result.prizeAmount);
            if (transfer.success) {
              updateResult(result.id, {
                winner: {
                  ...result.winner,
                  claimed: true,
                  transactionHash: transfer.transactionHash
                }
              });
            }
          } catch (error) {
            console.error('Prize transfer failed:', error);
          }
        } else if (!result.winner.claimed && !result.winner.ethAddress && !result.winner.notified) {
          // Send email notification for unclaimed prizes
          await sendWinningEmail(result.winner.email, result);
          updateResult(result.id, {
            winner: {
              ...result.winner,
              notified: true,
              claimDeadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days from now
            }
          });
        }
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [results, updateResult]);

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const formatTimeLeft = (deadline: Date) => {
    const now = new Date();
    const timeLeft = deadline.getTime() - now.getTime();
    const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
    const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    return `${days}d ${hours}h`;
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 shadow-xl">
      <div className="flex items-center space-x-3 mb-8">
        <Trophy className="w-8 h-8 text-yellow-400" />
        <h2 className="text-2xl font-bold text-white">Live Draw Results</h2>
      </div>

      <div className="space-y-6">
        {latestResults.length === 0 ? (
          <div className="text-center text-gray-400 py-8">
            <Clock className="w-12 h-12 mx-auto mb-4 animate-pulse" />
            <p>Waiting for next draw...</p>
          </div>
        ) : (
          latestResults.map((result) => (
            <div key={result.id} className="bg-black/20 rounded-xl p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold mb-2 ${
                    result.type.includes('daily') ? 'bg-purple-600' : 'bg-yellow-600'
                  }`}>
                    {result.type.split('-').map(word => 
                      word.charAt(0).toUpperCase() + word.slice(1)
                    ).join(' ')}
                  </span>
                  <div className="text-gray-400">{formatDate(result.drawTime)}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-400">Prize</div>
                  <div className="text-xl font-bold text-yellow-400">
                    ${result.prizeAmount.toFixed(2)}
                  </div>
                </div>
              </div>

              {result.winningNumbers ? (
                <div className="mb-4">
                  <div className="text-sm text-gray-400 mb-2">Winning Numbers</div>
                  <div className="flex space-x-2">
                    {result.winningNumbers.map((num, index) => (
                      <div
                        key={index}
                        className="w-10 h-10 rounded-full bg-yellow-400 text-black flex items-center justify-center font-bold"
                      >
                        {num}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="mb-4">
                  <div className="text-sm text-gray-400 mb-2">Winning Ticket</div>
                  <div className="text-2xl font-bold text-yellow-400">
                    #{result.winningTicket}
                  </div>
                </div>
              )}

              <div className="border-t border-white/10 pt-4">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="text-sm text-gray-400">Winner</div>
                    <div className="font-semibold">{result.winner.username}</div>
                  </div>
                  {result.winner.claimed ? (
                    <a
                      href={`https://etherscan.io/tx/${result.winner.transactionHash}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-1 text-yellow-400 hover:text-yellow-500"
                    >
                      <span>View Transaction</span>
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  ) : result.winner.claimDeadline ? (
                    <div className="flex items-center space-x-2 text-red-400">
                      <AlertTriangle className="w-4 h-4" />
                      <span>Claim within {formatTimeLeft(result.winner.claimDeadline)}</span>
                    </div>
                  ) : (
                    <div className="text-gray-400">Processing...</div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}