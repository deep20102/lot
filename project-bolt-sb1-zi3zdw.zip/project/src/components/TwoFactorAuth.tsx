import { useState } from 'react';
import { QrCode, Copy, Check } from 'lucide-react';

interface TwoFactorAuthProps {
  isEnabled: boolean;
  onEnable: () => void;
  onDisable: () => void;
}

export default function TwoFactorAuth({ isEnabled, onEnable, onDisable }: TwoFactorAuthProps) {
  const [showQR, setShowQR] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [secretKey, setSecretKey] = useState('ABCD EFGH IJKL MNOP');
  const [copied, setCopied] = useState(false);

  const handleCopyKey = () => {
    navigator.clipboard.writeText(secretKey.replace(/\s/g, ''));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleVerification = () => {
    // Mock API call to verify the code
    if (verificationCode === '123456') {
      onEnable();
      setShowQR(false);
    }
  };

  if (!isEnabled) {
    return (
      <div className="space-y-4">
        {!showQR ? (
          <button
            onClick={() => setShowQR(true)}
            className="w-full bg-yellow-400 text-black px-4 py-2 rounded-lg hover:bg-yellow-500"
          >
            Enable 2FA
          </button>
        ) : (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-lg w-48 h-48 mx-auto">
              <QrCode className="w-full h-full text-black" />
            </div>
            
            <div className="relative">
              <div className="flex items-center justify-between bg-black/20 rounded-lg p-2">
                <code className="font-mono text-sm">{secretKey}</code>
                <button
                  onClick={handleCopyKey}
                  className="text-yellow-400 hover:text-yellow-500"
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              {copied && (
                <div className="absolute -top-8 right-0 bg-green-500 text-white px-2 py-1 rounded text-sm">
                  Copied!
                </div>
              )}
            </div>

            <input
              type="text"
              maxLength={6}
              placeholder="Enter 6-digit code"
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
              className="w-full bg-black/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400 text-center text-2xl tracking-wider"
            />

            <div className="flex space-x-2">
              <button
                onClick={() => setShowQR(false)}
                className="flex-1 bg-gray-600 px-4 py-2 rounded-lg hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleVerification}
                disabled={verificationCode.length !== 6}
                className="flex-1 bg-yellow-400 text-black px-4 py-2 rounded-lg hover:bg-yellow-500 disabled:bg-gray-600 disabled:text-gray-400"
              >
                Verify
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <button
      onClick={onDisable}
      className="w-full bg-red-600 px-4 py-2 rounded-lg hover:bg-red-700"
    >
      Disable 2FA
    </button>
  );
}