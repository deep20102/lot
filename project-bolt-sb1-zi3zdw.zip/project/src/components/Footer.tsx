import { Ticket, Mail, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-black/30 backdrop-blur-sm border-t border-white/10 text-white mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Ticket className="w-6 h-6 text-yellow-400" />
              <span className="text-xl font-bold">LuckyDraw</span>
            </div>
            <p className="text-gray-400">
              Your trusted platform for daily and weekly lottery games.
              Play responsibly and win big!
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-yellow-400">Home</Link>
              </li>
              <li>
                <Link to="/results" className="text-gray-400 hover:text-yellow-400">Results</Link>
              </li>
              <li>
                <Link to="/profile" className="text-gray-400 hover:text-yellow-400">My Account</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-gray-400">
                <Mail className="w-4 h-4" />
                <span>support@luckydraw.com</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-400">
                <Phone className="w-4 h-4" />
                <span>+1 (555) 123-4567</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/10 mt-8 pt-8 text-center text-gray-400">
          <p>© 2024 LuckyDraw. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}