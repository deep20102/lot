import { useState } from 'react';
import { Lock } from 'lucide-react';
import PasswordInput from './PasswordInput';
import { usePasswordValidation } from '../../hooks/usePasswordValidation';

interface PasswordChangeFormProps {
  onSubmit: (currentPassword: string, newPassword: string) => Promise<void>;
}

export default function PasswordChangeForm({ onSubmit }: PasswordChangeFormProps) {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const {
    passwordError,
    confirmPasswordError,
    validatePassword,
    validatePasswordMatch,
    setPasswordError,
    setConfirmPasswordError
  } = usePasswordValidation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    validatePassword(newPassword);
    validatePasswordMatch(newPassword, confirmPassword);
    
    try {
      await onSubmit(currentPassword, newPassword);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setPasswordError('');
      setConfirmPasswordError('');
    } catch (error) {
      console.error('Failed to update password:', error);
    }
  };

  return (
    <div className="bg-black/20 rounded-xl p-4">
      <div className="flex items-center space-x-2 mb-4">
        <Lock className="w-5 h-5 text-yellow-400" />
        <span className="font-semibold">Change Password</span>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <PasswordInput
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          placeholder="Current Password"
        />
        <PasswordInput
          value={newPassword}
          onChange={(e) => {
            setNewPassword(e.target.value);
            validatePassword(e.target.value);
            if (confirmPassword) {
              validatePasswordMatch(e.target.value, confirmPassword);
            }
          }}
          placeholder="New Password"
          error={passwordError}
        />
        <PasswordInput
          value={confirmPassword}
          onChange={(e) => {
            setConfirmPassword(e.target.value);
            validatePasswordMatch(newPassword, e.target.value);
          }}
          placeholder="Confirm New Password"
          error={confirmPasswordError}
        />
        <button
          type="submit"
          className="w-full bg-purple-600 hover:bg-purple-700 py-2 rounded-lg font-semibold"
        >
          Update Password
        </button>
      </form>
    </div>
  );
}